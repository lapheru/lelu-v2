# PHASE 14 — GENESIS ORCHESTRATOR

## Honest scope statement first
Same constraint as Phase 12 and 13: no network egress, no
`node_modules` in this upload, so nothing here was run through
`tsc`, Vite, or a browser. Everything below was written by reading
the existing engine/render/interface files directly and matching
their existing patterns as closely as possible, but it is unverified
by any build.

The brief asks for orchestration across ~39 engines, the full render
tree, the desktop, workspace, browser, dock, and chat. I did not
attempt a sweeping pass across all of it. Instead this phase builds
the orchestration layer itself — the piece that didn't exist at
all — and wires it into a representative, load-bearing subset of
consumers, rather than touching every leaf component in
`render/`, `materials/`, `systems/`, and `interface/`.

## What existed before this phase
Every engine already reads and writes one shared `GenesisState`
object every frame, in registration order (`EngineRegistry.update`).
That's real, working implicit coupling — MemoryEngine's output this
tick is already visible to whatever runs after it. `EngineBus`
already does one piece of real orchestration on top of that: it
derives the five shell weights (plasma/ocean/crystal/electric/halo)
from named slices of `GenesisState` and smooths them.

What didn't exist: anything that named the engine-to-engine
influence chain the brief describes (Memory → Learning → Curiosity
→ Exploration → Growth → Evolution → Reality), anything tracking
the Genesis Core's Birth → ... → Rebirth cycle as a real derived
state machine rather than a scripted animation, and any single
place blending all of it for consumers outside the shell system —
`EnginePipeline.ts` existed but was never imported anywhere
(dead code, left as-is).

Also worth noting: `src/app/scene/genesis/interface/{Desktop,
DesktopController, Workspace, WorkspaceManager, ...}.ts` is a
fairly deep class hierarchy, but `DesktopController` — the one
thing that ties it together — has zero imports anywhere in the
codebase. It's unwired scaffolding, not the live UI. The live
desktop/workspace/chat UI is `GenesisInterface.tsx` (mounted from
`GenesisScene.tsx`), so that's what got the ambient wiring below,
not the `interface/` class tree. Likewise `src/components/
{ChatWindow,MessageBubble,LeluChat}.tsx` are unimported dead code —
the live chat is `GenesisChat.tsx` + the message list in
`GenesisInterface.tsx`, which is what got touched.

## What this phase adds

### `src/app/scene/genesis/orchestrator/GenesisOrchestrator.ts` (new)
Reads `GenesisState` — the same object every engine reads — and
derives seven smoothed "drive" signals forming the chain the brief
asks for: `memoryDrive → learningDrive → curiosityDrive →
explorationDrive → growthDrive → evolutionDrive → realityDrive`.
Each target blends that stage's own owning field(s) with the
previous stage's drive, so influence genuinely flows forward through
the chain over a few frames rather than being read independently.

It also owns the Genesis Core's ten-phase lifecycle (Birth, Growth,
Learning, Expansion, Complexity, Instability, Collapse, Explosion,
Reorganization, Rebirth) as a real state machine whose advance speed
is driven by the state that phase represents (emergence, growth,
instability, mutation, stability, ...) rather than a fixed timer —
"never scripted" per the brief.

It never writes into `GenesisState` and never calls an engine. It's
a pure reader, same contract as `EngineBus`.

### `src/app/scene/genesis/orchestrator/ExpressionGraph.ts` (new)
The single blending layer the brief calls for. Takes `EngineBus`'s
existing shell weights (reused, not recomputed) and
`GenesisOrchestrator`'s drives and exposes them as named channels:
`core` (phase/progress/complexity/breathing), `environment`
(atmosphere/ocean/particles/lighting/postProcessing), `living`
(memoryVeins/mutation/lifeEvolution), and `ambient` (a single
aliveness + hue pair meant for chrome outside the 3D scene —
desktop/workspace/browser/chat). Nothing here duplicates a render
path; it only names combinations of numbers that already exist.

### `src/app/scene/genesis/engines/EngineRuntime.ts` (edited)
Instantiates the orchestrator and expression graph alongside the
existing registry/engineBus, runs them each tick
(`registry.update` → `orchestrator.update` → `engineBus.update` →
`expressionGraph.update`), and exposes `getOrchestrator()` /
`getExpressionGraph()` next to the existing `getEngineBus()`. Also
threaded the previously-unused `GenesisSignals` parameter through to
`engineBus.update()`, which already accepted it optionally.

### Renderer wiring (edited, additive only)
Three components that already read raw `GenesisState` slices
directly now also blend in the matching orchestrated channel,
following the codebase's existing pattern of each leaf component
pulling `engineRuntime` from `useGenesis()` itself:
- `materials/GenesisCore.tsx` — `core.breathing` blended into the
  permanent heartbeat pulse (the Birth → Rebirth cycle reaching the
  actual core mesh).
- `render/CoreMemoryVeins.tsx` — `living.memoryVeins`.
- `render/CoreMutationVisualizer.tsx` — `living.mutation`.
- `render/LifeEvolutionVisualizer.tsx` — `living.lifeEvolution`.

Each blend is additive with a small coefficient and falls back to
the pre-existing behavior if `engineRuntime` is null, so none of
these should regress if the orchestrator layer fails to mount.

### Desktop/workspace/chat ambience (edited, presentation only)
`GenesisInterface.tsx` — the live panel — now reads
`expressionGraph.getChannels().ambient` and uses it for two purely
cosmetic things: the panel's border/glow hue-and-intensity, and
assistant message bubbles' accent border. No chat logic, routing,
or message handling was touched — `GenesisChat.tsx`'s `AIService`
call is untouched, as is everything under `core/` on the DO NOT
TOUCH list.

## What's still open
- `render/CoreAtmosphere.tsx`, `Ocean.tsx`, the shell materials, and
  particle/post-processing systems are not yet reading
  `ExpressionGraph` — `Ocean.tsx` and the shells already read raw
  state/weights directly, which still works, but isn't running
  through the new blending layer yet.
- The `interface/` class hierarchy (Desktop, DesktopController,
  Workspace, dock, windows) remains genuinely disconnected from the
  live UI. Wiring ambience into it wouldn't be visible to a user
  until something actually mounts `DesktopController`, which is a
  separate, larger gap than this phase's brief.
- No visual or type-check verification was possible in this
  environment (see top of report).

## Files touched
```
NEW   src/app/scene/genesis/orchestrator/GenesisOrchestrator.ts
NEW   src/app/scene/genesis/orchestrator/ExpressionGraph.ts
NEW   src/app/scene/genesis/orchestrator/index.ts
EDIT  src/app/scene/genesis/engines/EngineRuntime.ts
EDIT  src/app/scene/genesis/materials/GenesisCore.tsx
EDIT  src/app/scene/genesis/render/CoreMemoryVeins.tsx
EDIT  src/app/scene/genesis/render/CoreMutationVisualizer.tsx
EDIT  src/app/scene/genesis/render/LifeEvolutionVisualizer.tsx
EDIT  src/app/scene/genesis/GenesisInterface.tsx
```
`AIService`, `AIRuntime`, `ProviderRuntime`, `ProviderRegistry`, the
provider integrations, `MemoryBridge`, chat/cognition routing, and
the rest of the existing API pipeline were not opened for editing.
