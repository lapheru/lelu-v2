/**
 * ==========================================================
 * LÉLUVERSE
 * LIFE EVOLUTION VISUALIZER
 *
 * Living biosphere surrounding the Genesis.
 *
 * Thin life field that hugs the planet instead
 * of becoming another giant sphere.
 * ==========================================================
 */

import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import { Group } from "three";

import { useGenesis } from "../GenesisCore";

export default function LifeEvolutionVisualizer() {

  const { universe, engineRuntime } = useGenesis();

  const lifeGroup = useRef<Group>(null);

  const growthGroup = useRef<Group>(null);

  const time = useRef(0);

  const organisms = useMemo(
    () =>
      Array.from({
        length: 24,
      }),
    [],
  );

  useFrame((_, delta) => {

    if (
      !lifeGroup.current ||
      !growthGroup.current
    ) {
      return;
    }

    time.current += delta;

    const life =
      universe.life ?? 0;

    const energy =
      universe.energy ?? 0;

    const awareness =
      universe.awareness ?? 0;

    const intelligence =
      universe.intelligence ?? 0;

    const growth =
      universe.evolutionSystem?.growth ?? 0;

    const mutation =
      universe.evolutionSystem?.mutation ?? 0;

    const adaptation =
      universe.evolutionSystem?.adaptation ?? 0;

    const orchestratedLife =

      engineRuntime
        ?.getExpressionGraph()
        .getChannels()
        .living
        .lifeEvolution ??
      0;

    const activity =

      (
        life +
        energy +
        awareness +
        intelligence +
        growth +
        mutation +
        adaptation +
        orchestratedLife
      ) / 8;

    lifeGroup.current.scale.setScalar(

      1 +

      Math.sin(
        time.current * 0.40,
      ) *

      (
        0.003 +
        activity * 0.006
      ),

    );

    growthGroup.current.rotation.y +=

      delta *

      (
        0.02 +
        activity * 0.05
      );

    growthGroup.current.rotation.x =

      Math.sin(
        time.current * 0.15,
      ) *

      0.02 *

      activity;

  });

  const energySafe =
    universe.energy ?? 0;

  const awarenessSafe =
    universe.awareness ?? 0;

  return (

    <group
      ref={lifeGroup}
      name="LifeEvolution"
      renderOrder={10}
    >

      <mesh renderOrder={10}>

        <sphereGeometry
          args={[
            0.845,
            64,
            64,
          ]}
        />

        <meshBasicMaterial
          color="#55ff99"
          transparent
          opacity={
            0.006 +
            energySafe * 0.012
          }
          depthWrite={false}
          toneMapped={false}
        />

      </mesh>

      <group
        ref={growthGroup}
        name="EvolutionNodes"
      >

        {

          organisms.map((_, i) => (

            <mesh
              key={i}
              position={[

                Math.sin(i * 0.9) * 0.82,

                Math.cos(i * 1.3) * 0.82,

                Math.sin(i * 2.1) * 0.82,

              ]}
            >

              <sphereGeometry
                args={[
                  0.010 +
                  (i % 3) * 0.003,
                  10,
                  10,
                ]}
              />

              <meshBasicMaterial
                color="#8cffb8"
                transparent
                opacity={
                  0.04 +
                  awarenessSafe * 0.10
                }
                depthWrite={false}
                toneMapped={false}
              />

            </mesh>

          ))

        }

      </group>

      <pointLight
        color="#66ff99"
        intensity={
          0.35 +
          energySafe * 0.60
        }
        distance={2.8}
      />

    </group>

  );

}