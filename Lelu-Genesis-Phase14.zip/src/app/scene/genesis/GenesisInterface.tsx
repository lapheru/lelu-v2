/**
 * ==========================================================
 * LÉLUVERSE
 * GENESIS INTERFACE
 * ==========================================================
 */

import { useEffect, useMemo, useRef } from "react";
import { useGenesis } from "./GenesisCore";
import GenesisChat from "./GenesisChat";

export default function GenesisInterface() {
  const {
    state,
    engineRuntime,
    openPanel,
    focusWorkspace,
    selectDestination,
    addMessage,
    setThinking,
    notify,
  } = useGenesis();

  const ambient =
    engineRuntime
      ?.getExpressionGraph()
      .getChannels()
      .ambient ??
    { aliveness: 0, hue: 0 };

  const workspaces = useMemo(
    () => state.cognition?.workspaces ?? [],
    [state.cognition?.workspaces],
  );

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [state.messages.length, state.thinking]);

  function handleWorkspace(id: string, name: string, index: number) {
    focusWorkspace(id);
    selectDestination({
      id,
      type: "workspace",
      name,
      position: { x: index * 3 - 3, y: 0, z: -5 },
    });
  }

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        pointerEvents: "none",
        zIndex: 20,
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 16,
          left: 16,
          display: "flex",
          flexDirection: "column",
          gap: 10,
          pointerEvents: "auto",
          maxWidth: 420,
          width: "calc(100vw - 32px)",
        }}
      >
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button type="button" onClick={() => openPanel("chat")}>Chat</button>
          <button type="button" onClick={() => handleWorkspace("core", "Genesis Core", 0)}>Core</button>
          <button type="button" onClick={() => handleWorkspace("research", "Research Lab", 1)}>Research</button>
          <button type="button" onClick={() => handleWorkspace("creation", "Creation Studio", 2)}>Create</button>
        </div>

        <div
          style={{
            background: "rgba(2, 6, 23, 0.88)",
            border: `1px solid hsla(${210 + ambient.hue}, 90%, 70%, ${0.16 + ambient.aliveness * 0.14})`,
            borderRadius: 16,
            padding: 12,
            color: "white",
            backdropFilter: "blur(16px)",
            boxShadow: `0 18px 60px rgba(0,0,0,0.35), 0 0 ${24 + ambient.aliveness * 40}px hsla(${210 + ambient.hue}, 90%, 60%, ${ambient.aliveness * 0.12})`,
            transition: "border-color 1.2s ease, box-shadow 1.2s ease",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <strong>Genesis</strong>
            <span style={{ opacity: 0.75 }}>
              {state.runtimeReady ? "Live" : "Booting"}
            </span>
          </div>

          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8 }}>
            {workspaces.map((workspace: any, index: number) => (
              <button
                key={workspace.id ?? index}
                type="button"
                onClick={() =>
                  handleWorkspace(
                    workspace.id ?? String(index),
                    workspace.name ?? "Workspace",
                    index,
                  )
                }
              >
                {workspace.name ?? "Workspace"}
              </button>
            ))}
          </div>

          <div style={{ opacity: 0.8, fontSize: 12, marginBottom: 10 }}>
            Active destination: {state.activeDestination ?? "None"}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div
              aria-live="polite"
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 8,
                maxHeight: 320,
                overflowY: "auto",
                padding: 4,
                borderRadius: 12,
                background: "rgba(255,255,255,0.025)",
              }}
            >
              {state.messages.length === 0 ? (
                <div style={{ padding: "18px 12px", textAlign: "center", opacity: 0.65, fontSize: 13 }}>
                  Start a conversation with Lélu.
                </div>
              ) : (
                state.messages.map((message) => (
                  <div
                    key={message.id}
                    style={{
                      display: "flex",
                      justifyContent: message.role === "user" ? "flex-end" : "flex-start",
                      width: "100%",
                    }}
                  >
                    <div
                      style={{
                        maxWidth: "86%",
                        padding: "10px 12px",
                        borderRadius: message.role === "user"
                          ? "16px 16px 4px 16px"
                          : "16px 16px 16px 4px",
                        background: message.role === "user"
                          ? "rgba(120,80,255,0.92)"
                          : "rgba(255,255,255,0.09)",
                        border: message.role === "user"
                          ? "1px solid rgba(180,160,255,0.24)"
                          : `1px solid hsla(${210 + ambient.hue}, 80%, 70%, ${0.08 + ambient.aliveness * 0.14})`,
                        color: "white",
                        whiteSpace: "pre-wrap",
                        overflowWrap: "break-word",
                        lineHeight: 1.5,
                      }}
                    >
                      <div style={{ fontSize: 10, fontWeight: 700, opacity: 0.6, marginBottom: 4, letterSpacing: 0.4 }}>
                        {message.role === "user" ? "YOU" : "LÉLU"}
                      </div>
                      <div>{message.text}</div>
                      {message.provider && message.role === "assistant" ? (
                        <div style={{ fontSize: 9, opacity: 0.45, marginTop: 6 }}>
                          {message.provider}
                        </div>
                      ) : null}
                    </div>
                  </div>
                ))
              )}

              {state.thinking ? (
                <div
                  style={{
                    alignSelf: "flex-start",
                    padding: "9px 12px",
                    borderRadius: 16,
                    background: "rgba(255,255,255,0.06)",
                    color: "rgba(255,255,255,0.7)",
                    fontSize: 12,
                  }}
                >
                  Lélu is thinking…
                </div>
              ) : null}

              <div ref={messagesEndRef} />
            </div>

            <GenesisChat
              addMessage={addMessage}
              setThinking={setThinking}
              notify={notify}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
