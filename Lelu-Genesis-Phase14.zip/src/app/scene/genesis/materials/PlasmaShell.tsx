/**
 * ==========================================================
 * LÉLUVERSE
 * PLASMA SHELL
 *
 * Innermost shell — raw formative energy roiling just
 * beneath the Crystal lattice. This is what the other four
 * shells are condensing out of.
 * ==========================================================
 */

import {
  useFrame,
} from "@react-three/fiber";

import {
  useMemo,
  useRef,
} from "react";

import {
  Mesh,
} from "three";

import PlasmaMaterial
  from "./PlasmaMaterial";

interface Props {

  activity: number;

}

export default function PlasmaShell({

  activity,

}: Props) {

  const shell =

    useRef<Mesh>(null);

  const material =

    useMemo(

      () => new PlasmaMaterial(),

      [],

    );

  useFrame((_, delta) => {

    if (!material?.uniforms) {

      return;

    }

    const uTime = material.uniforms.uTime;
    const uActivity = material.uniforms.uActivity;

    if (uTime?.value !== undefined) {

      uTime.value += delta;

    }

    if (uActivity?.value !== undefined) {

      uActivity.value =
        activity;

    }

    if (!shell.current) {

      return;

    }

    shell.current.rotation.y -=
      delta * 0.03;

    shell.current.rotation.z +=
      delta * 0.021;

  });

  return (

    <mesh

      ref={shell}

      renderOrder={202}

      material={material}

    >

      <icosahedronGeometry

        args={[

          0.58,

          48,

        ]}

      />

    </mesh>

  );

}
