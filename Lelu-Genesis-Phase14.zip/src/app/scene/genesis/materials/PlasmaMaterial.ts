import {
  AdditiveBlending,
  Color,
  FrontSide,
  ShaderMaterial,
} from "three";

/**
 * ==========================================================
 * LÉLUVERSE
 * PLASMA MATERIAL
 *
 * Raw formative energy — the innermost of the five shells.
 * Where Crystal is structured and Electric is instantaneous,
 * Plasma is the roiling, molten substrate everything else
 * condenses out of. It never sits still, even at rest.
 * ==========================================================
 */
export default class PlasmaMaterial extends ShaderMaterial {

  constructor() {

    super({

      transparent: true,
      depthWrite: false,
      side: FrontSide,
      blending: AdditiveBlending,

      uniforms: {

        uTime: {
          value: 0,
        },

        uActivity: {
          value: 0,
        },

        uColorA: {
          value: new Color("#3fc9ff"),
        },

        uColorB: {
          value: new Color("#b98bff"),
        },

        uBrightness: {
          value: 1,
        },

      },

      vertexShader: `

varying vec3 vNormal;
varying vec3 vPosition;

uniform float uTime;
uniform float uActivity;

float hash(vec3 p){

    return fract(
        sin(
            dot(
                p,
                vec3(12.9898, 78.233, 45.164)
            )
        ) * 43758.5453
    );

}

void main(){

    vNormal = normal;
    vPosition = position;

    float roil =
        sin(position.x * 9.0 + uTime * 1.6) *
        sin(position.y * 7.0 - uTime * 1.3) *
        sin(position.z * 8.0 + uTime * 1.1);

    roil +=
        hash(floor(position * 6.0 + uTime * 0.4)) * 0.4;

    float displacement =
        roil *
        0.05 *
        (0.4 + uActivity);

    vec3 displaced =
        position +
        normal * displacement;

    gl_Position =
        projectionMatrix *
        modelViewMatrix *
        vec4(displaced, 1.0);

}

`,

      fragmentShader: `

uniform float uTime;
uniform float uActivity;
uniform float uBrightness;

uniform vec3 uColorA;
uniform vec3 uColorB;

varying vec3 vNormal;
varying vec3 vPosition;

float hash(vec3 p){

    return fract(
        sin(
            dot(
                p,
                vec3(127.1, 311.7, 74.7)
            )
        ) * 43758.5453
    );

}

float noise(vec3 p){

    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    float a = hash(i);
    float b = hash(i + vec3(1.0, 0.0, 0.0));
    float c = hash(i + vec3(0.0, 1.0, 0.0));
    float d = hash(i + vec3(1.0, 1.0, 0.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);

}

void main(){

    float flow =
        noise(vPosition * 4.0 + uTime * 0.5) * 0.6 +
        noise(vPosition * 9.0 - uTime * 0.8) * 0.4;

    flow =
        smoothstep(
            0.25,
            0.85,
            flow
        );

    float fresnel =
        pow(
            1.0 -
            abs(
                dot(
                    normalize(vNormal),
                    vec3(0.0, 0.0, 1.0)
                )
            ),
            2.2
        );

    vec3 color =
        mix(
            uColorA,
            uColorB,
            flow
        );

    color *=
        (
            0.55 +
            flow * 1.3 +
            fresnel * 0.6
        );

    color *=
        (
            0.35 +
            uActivity * 1.15
        );

    color *=
        uBrightness;

    float alpha =
        clamp(
            flow * 0.7 +
            fresnel * 0.35,
            0.0,
            1.0
        ) *
        (0.25 + uActivity * 0.85);

    gl_FragColor =
        vec4(
            color,
            alpha
        );

}

`,

    });

  }

}
