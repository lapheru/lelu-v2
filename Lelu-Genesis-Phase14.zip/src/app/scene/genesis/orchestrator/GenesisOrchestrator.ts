/**
 * ==========================================================
 * LÉLUVERSE
 * GENESIS ORCHESTRATOR
 *
 * Phase 14 — the orchestration layer.
 *
 * The engines already share one GenesisState, and they
 * already shape each other indirectly: every engine reads
 * and writes the same object every frame, in registration
 * order, so whatever MemoryEngine leaves in `state.memory`
 * this tick is already visible to whatever runs after it.
 * What was missing was anything that named that chain,
 * smoothed it, and made it legible to the presentation layer.
 *
 * The Orchestrator does exactly that and nothing else:
 *
 * - It never calls an engine directly.
 * - It never writes back into GenesisState.
 * - It never owns or duplicates a field an engine owns.
 *
 * It reads the same GenesisState every engine already reads,
 * derives a small set of named "drive" signals describing how
 * strongly one concern is currently pushing the next —
 *
 *   Memory -> Learning -> Curiosity -> Exploration
 *          -> Growth -> Evolution -> Reality
 *
 * — and tracks the Genesis Core's living cycle (Birth ...
 * Rebirth). Every value here is smoothed and re-derived every
 * frame, exactly like EngineBus's shell weights one layer
 * below — this is just one layer above them.
 *
 * The ExpressionGraph (./ExpressionGraph.ts) is the only
 * consumer that turns this into renderer / desktop / UI
 * channels — nothing else should read GenesisState in order
 * to decide how "alive" the presentation looks.
 * ==========================================================
 */

import type { GenesisState } from "../state/GenesisState";
import type { GenesisSignals } from "../engines/GenesisSignals";

function clamp01(value: number): number {

  return Math.min(1, Math.max(0, value));

}

function approach(
  current: number,
  target: number,
  delta: number,
  rate: number,
): number {

  const speed =
    Math.min(delta * rate, 1);

  return current + (target - current) * speed;

}

export type GenesisCorePhase =
  | "BIRTH"
  | "GROWTH"
  | "LEARNING"
  | "EXPANSION"
  | "COMPLEXITY"
  | "INSTABILITY"
  | "COLLAPSE"
  | "EXPLOSION"
  | "REORGANIZATION"
  | "REBIRTH";

const CORE_PHASES: GenesisCorePhase[] = [

  "BIRTH",
  "GROWTH",
  "LEARNING",
  "EXPANSION",
  "COMPLEXITY",
  "INSTABILITY",
  "COLLAPSE",
  "EXPLOSION",
  "REORGANIZATION",
  "REBIRTH",

];

export interface OrchestrationDrives {

  /** Memory feeding Learning. */
  memoryDrive: number;

  /** Learning feeding Curiosity. */
  learningDrive: number;

  /** Curiosity feeding Exploration. */
  curiosityDrive: number;

  /** Exploration feeding Growth. */
  explorationDrive: number;

  /** Growth feeding Evolution. */
  growthDrive: number;

  /** Evolution feeding Reality. */
  evolutionDrive: number;

  /** Reality — the end of the chain, what the renderer reads. */
  realityDrive: number;

}

export interface OrchestrationState extends OrchestrationDrives {

  corePhase: GenesisCorePhase;

  /** 0..1 progress through the current phase. */
  corePhaseProgress: number;

  /** 0..1 — how structurally complex the core currently reads. */
  coreComplexity: number;

}

const zeroDrives: OrchestrationDrives = {
  memoryDrive: 0,
  learningDrive: 0,
  curiosityDrive: 0,
  explorationDrive: 0,
  growthDrive: 0,
  evolutionDrive: 0,
  realityDrive: 0,
};

export default class GenesisOrchestrator {

  private drives: OrchestrationDrives = {
    ...zeroDrives,
  };

  private phaseIndex = 0;

  private phaseProgress = 0;

  update(

    state: GenesisState,

    delta: number,

    signals?: GenesisSignals,

  ): void {

    this.updateDrives(state, delta, signals);

    this.updateCorePhase(state, delta);

  }

  /**
   * Every target here is deliberately built from the previous
   * drive plus that stage's own owning fields — that's the
   * "Memory should influence Learning" chain the phase brief
   * asks for, expressed as a blend rather than a direct write.
   */
  private updateDrives(

    state: GenesisState,

    delta: number,

    signals?: GenesisSignals,

  ): void {

    const memory = state.memory;
    const evo = state.evolutionSystem;

    const memoryTarget = clamp01(
      memory.shortTerm * 0.3 +
      memory.longTerm * 0.4 +
      memory.importance * 0.3,
    );

    const learningTarget = clamp01(
      state.learning * 0.55 +
      this.drives.memoryDrive * 0.45,
    );

    const curiosityTarget = clamp01(
      state.curiosity * 0.55 +
      this.drives.learningDrive * 0.45,
    );

    const explorationTarget = clamp01(
      this.drives.curiosityDrive * 0.6 +
      state.awareness * 0.2 +
      (signals?.reasoningActive ? 0.2 : 0),
    );

    const growthTarget = clamp01(
      evo.growth * 0.5 +
      this.drives.explorationDrive * 0.5,
    );

    const evolutionTarget = clamp01(
      state.evolution * 0.45 +
      this.drives.growthDrive * 0.35 +
      evo.mutation * 0.2,
    );

    const realityTarget = clamp01(
      state.reality * 0.5 +
      this.drives.evolutionDrive * 0.3 +
      state.existence * 0.2,
    );

    // Same smoothing feel as EngineBus's shell weights.
    const rate = 3;

    this.drives = {
      memoryDrive: approach(this.drives.memoryDrive, memoryTarget, delta, rate),
      learningDrive: approach(this.drives.learningDrive, learningTarget, delta, rate),
      curiosityDrive: approach(this.drives.curiosityDrive, curiosityTarget, delta, rate),
      explorationDrive: approach(this.drives.explorationDrive, explorationTarget, delta, rate),
      growthDrive: approach(this.drives.growthDrive, growthTarget, delta, rate),
      evolutionDrive: approach(this.drives.evolutionDrive, evolutionTarget, delta, rate),
      realityDrive: approach(this.drives.realityDrive, realityTarget, delta, rate),
    };

  }

  /**
   * Advances the Genesis Core through Birth -> ... -> Rebirth.
   * Each phase's "pressure" is read from the state that phase
   * represents, so the cycle speeds up or stalls with what the
   * engines are actually doing rather than a fixed timer.
   */
  private updateCorePhase(

    state: GenesisState,

    delta: number,

  ): void {

    const evo = state.evolutionSystem;

    const phase = CORE_PHASES[this.phaseIndex];

    let pressure = 0;

    switch (phase) {

      case "BIRTH":
        pressure = evo.emergence;
        break;

      case "GROWTH":
        pressure = evo.growth;
        break;

      case "LEARNING":
        pressure = state.learning;
        break;

      case "EXPANSION":
        pressure = this.drives.explorationDrive;
        break;

      case "COMPLEXITY":
        pressure = state.intelligence * 0.5 + state.wisdom * 0.5;
        break;

      case "INSTABILITY":
        pressure = evo.instability;
        break;

      case "COLLAPSE":
        pressure = clamp01(evo.instability - state.stability);
        break;

      case "EXPLOSION":
        pressure = evo.mutation;
        break;

      case "REORGANIZATION":
        pressure = state.stability;
        break;

      case "REBIRTH":
        pressure = evo.emergence;
        break;

    }

    pressure = clamp01(pressure);

    // A phase always advances, even at rest — just slowly.
    this.phaseProgress +=
      delta * (0.04 + pressure * 0.12);

    if (this.phaseProgress >= 1) {

      this.phaseProgress = 0;

      this.phaseIndex =
        (this.phaseIndex + 1) % CORE_PHASES.length;

    }

  }

  getDrives(): OrchestrationDrives {

    return { ...this.drives };

  }

  getState(): OrchestrationState {

    return {

      ...this.drives,

      corePhase: CORE_PHASES[this.phaseIndex],

      corePhaseProgress: this.phaseProgress,

      coreComplexity: clamp01(
        this.drives.evolutionDrive * 0.6 +
        this.drives.realityDrive * 0.4,
      ),

    };

  }

}
