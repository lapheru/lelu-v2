/**
 * ==========================================================
 * LÉLUVERSE
 * EXPRESSION GRAPH
 *
 * The one place that blends engine + orchestrator state into
 * channels the renderer, desktop, workspace, browser and chat
 * are allowed to read.
 *
 * Nothing outside this file should read GenesisState directly
 * in order to decide how "alive" the presentation looks —
 * reading it here once and re-exposing it as named channels
 * means every consumer moves together instead of drifting out
 * of sync with its own bespoke blend.
 *
 * This reuses EngineBus's shell weights rather than
 * recomputing them (see EngineBus's own note on why those
 * five numbers are already the right signal for Crystal /
 * Electric / Halo / Plasma / Ocean) and reuses
 * GenesisOrchestrator's drives for everything downstream of
 * Memory -> ... -> Reality. It does not duplicate a render
 * path or a piece of state — it only names combinations of
 * numbers that already exist.
 * ==========================================================
 */

import type EngineBus, { EngineWeights } from "../engines/EngineBus";
import type GenesisOrchestrator from "./GenesisOrchestrator";
import type { GenesisState } from "../state/GenesisState";

function clamp01(value: number): number {

  return Math.min(1, Math.max(0, value));

}

export interface CoreChannel {

  phase: string;

  phaseProgress: number;

  complexity: number;

  /** 0..1 amplitude for the Birth -> Rebirth breathing pulse. */
  breathing: number;

}

export interface EnvironmentChannel {

  atmosphere: number;

  ocean: number;

  particles: {
    density: number;
    speed: number;
    dispersion: number;
  };

  lighting: number;

  postProcessing: number;

}

export interface LivingChannel {

  memoryVeins: number;

  mutation: number;

  lifeEvolution: number;

}

/**
 * A single low-frequency signal meant for surfaces outside the
 * 3D scene — desktop chrome, the workspace shell, the browser
 * app, chat presentation — anywhere a full shader-grade update
 * rate is unnecessary and only a subtle ambient shift is
 * wanted.
 */
export interface AmbientChannel {

  /** 0..1 — how "alive" the wider interface should feel right now. */
  aliveness: number;

  /** Degrees, small range — a subtle hue-rotate for chrome accents. */
  hue: number;

}

export interface ExpressionChannels {

  shells: EngineWeights;

  core: CoreChannel;

  environment: EnvironmentChannel;

  living: LivingChannel;

  ambient: AmbientChannel;

}

const emptyChannels: ExpressionChannels = {

  shells: {
    plasma: 0,
    ocean: 0,
    crystal: 0,
    electric: 0,
    halo: 0,
  },

  core: {
    phase: "BIRTH",
    phaseProgress: 0,
    complexity: 0,
    breathing: 0.3,
  },

  environment: {
    atmosphere: 0,
    ocean: 0,
    particles: { density: 0, speed: 0, dispersion: 0 },
    lighting: 0,
    postProcessing: 0,
  },

  living: {
    memoryVeins: 0,
    mutation: 0,
    lifeEvolution: 0,
  },

  ambient: {
    aliveness: 0,
    hue: 0,
  },

};

export default class ExpressionGraph {

  private readonly engineBus: EngineBus;

  private readonly orchestrator: GenesisOrchestrator;

  private channels: ExpressionChannels = {
    ...emptyChannels,
  };

  constructor(

    engineBus: EngineBus,

    orchestrator: GenesisOrchestrator,

  ) {

    this.engineBus = engineBus;

    this.orchestrator = orchestrator;

  }

  update(

    state: GenesisState,

  ): void {

    const shells =
      this.engineBus.getWeights();

    const drives =
      this.orchestrator.getState();

    const core: CoreChannel = {

      phase: drives.corePhase,

      phaseProgress: drives.corePhaseProgress,

      complexity: drives.coreComplexity,

      breathing: clamp01(
        0.3 +
        drives.evolutionDrive * 0.4 +
        shells.plasma * 0.3,
      ),

    };

    const environment: EnvironmentChannel = {

      atmosphere: clamp01(
        state.light * 0.3 +
        state.awareness * 0.3 +
        shells.halo * 0.4,
      ),

      ocean: shells.ocean,

      particles: {
        density: state.particles.density,
        speed: state.particles.speed,
        dispersion: state.particles.dispersion,
      },

      lighting: clamp01(
        state.energy * 0.4 +
        state.consciousness * 0.3 +
        drives.realityDrive * 0.3,
      ),

      postProcessing: clamp01(
        shells.electric * 0.5 +
        drives.evolutionDrive * 0.5,
      ),

    };

    const living: LivingChannel = {

      memoryVeins: clamp01(
        drives.memoryDrive * 0.7 +
        state.memory.importance * 0.3,
      ),

      mutation: clamp01(
        state.evolutionSystem.mutation * 0.6 +
        drives.evolutionDrive * 0.4,
      ),

      lifeEvolution: clamp01(
        state.life * 0.4 +
        drives.growthDrive * 0.4 +
        drives.explorationDrive * 0.2,
      ),

    };

    const ambient: AmbientChannel = {

      aliveness: clamp01(
        shells.halo * 0.25 +
        shells.crystal * 0.2 +
        drives.realityDrive * 0.25 +
        drives.evolutionDrive * 0.15 +
        environment.lighting * 0.15,
      ),

      hue:
        (drives.corePhaseProgress * 12 - 6) +
        (drives.evolutionDrive - 0.5) * 20,

    };

    this.channels = {
      shells,
      core,
      environment,
      living,
      ambient,
    };

  }

  getChannels(): ExpressionChannels {

    return this.channels;

  }

}
