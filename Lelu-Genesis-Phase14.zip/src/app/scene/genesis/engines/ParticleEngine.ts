/**
 * ==========================================================
 * LÉLUVERSE
 * PARTICLE ENGINE
 * ==========================================================
 *
 * Publishes `state.particles` — a small, clearly-scoped reading
 * built only from fields that already legitimately exist
 * elsewhere in this codebase:
 *   - density    <- curiosity + energy (exploration needs both
 *                   something driving it and fuel to do it with)
 *   - speed      <- pulse.intensity (particles move with the
 *                   same heartbeat everything else responds to)
 *   - dispersion <- chaos (the same field OceanEngine and
 *                   EngineBus already treat as "instability")
 *
 * This publishes a value — it does not touch any renderer.
 * Wiring it to an actual particle system is Expression Layer
 * work elsewhere, not this engine's job.
 * ==========================================================
 */

import type {
  GenesisState,
} from "../state/GenesisState";

function clamp01(value: number): number {
  return Math.min(1, Math.max(0, value));
}

export default class ParticleEngine {

  update(
    state: GenesisState,
    _delta: number,
  ): void {

    if (state.paused) return;

    state.particles.density = clamp01(
      state.curiosity * 0.6 + state.energy * 0.4,
    );

    state.particles.speed = clamp01(
      state.pulse.intensity,
    );

    state.particles.dispersion = clamp01(
      state.chaos,
    );

  }

}
