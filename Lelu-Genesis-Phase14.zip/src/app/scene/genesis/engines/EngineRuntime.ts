/**
 * ==========================================================
 * LÉLUVERSE
 * ENGINE RUNTIME
 *
 * Living engine execution bridge.
 *
 * Connects:
 * - EngineRegistry
 * - EngineBootstrap
 * - GenesisState
 *
 * ==========================================================
 */


import EngineRegistry
  from "./EngineRegistry";


import EngineBootstrap
  from "./EngineBootstrap";


import type {
  GenesisState,
} from "../state/GenesisState";

import EngineBus
  from "./EngineBus";

import GenesisOrchestrator
  from "../orchestrator/GenesisOrchestrator";

import ExpressionGraph
  from "../orchestrator/ExpressionGraph";

import type { GenesisSignals } from "./GenesisSignals";



export default class EngineRuntime {



  private readonly registry:

    EngineRegistry;

private readonly engineBus:

  EngineBus;

/**
 * Phase 14 — orchestration layer. Reads the same
 * GenesisState every engine already reads; never writes
 * back into it. See ../orchestrator for the reasoning.
 */
private readonly orchestrator:

  GenesisOrchestrator;

private readonly expressionGraph:

  ExpressionGraph;



  constructor(){


    this.registry =

      new EngineRegistry();

this.engineBus =

  new EngineBus(

    this.registry,

  );

this.orchestrator =

  new GenesisOrchestrator();

this.expressionGraph =

  new ExpressionGraph(

    this.engineBus,

    this.orchestrator,

  );

    EngineBootstrap.register(

      this.registry,

    );


  }







  async initialize(): Promise<void> {

    await this.registry.initialize();

  }



  async dispatch(event:string, payload?:unknown): Promise<void> {

    await this.registry.dispatch(event, payload);

  }




update(
  state: GenesisState,
  delta: number,
  signals?: GenesisSignals,
): void {

  this.registry.update(
    state,
    delta,
  );

  this.orchestrator.update(
    state,
    delta,
    signals,
  );

  this.engineBus.update(
    state,
    delta,
    signals,
  );

  this.expressionGraph.update(
    state,
  );

}

getEngineBus(): EngineBus {

  return this.engineBus;

}

getOrchestrator(): GenesisOrchestrator {

  return this.orchestrator;

}

getExpressionGraph(): ExpressionGraph {

  return this.expressionGraph;

}







  







  getRegistry(){

    return this.registry;

  }

}