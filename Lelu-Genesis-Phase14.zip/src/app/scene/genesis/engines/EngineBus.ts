/**
 * ==========================================================
 * LÉLUVERSE
 * ENGINE BUS
 *
 * Central orchestration layer between
 * the EngineRegistry and Genesis Renderer.
 *
 * Responsibilities
 * • Collect engine influence
 * • Smooth transitions
 * • Drive shader uniforms
 * • Drive shell activity
 * • Runtime orchestration
 *
 * --------------------------------------------------------
 * NOTE ON WEIGHT SOURCING
 * --------------------------------------------------------
 * Shell activity used to be derived by matching each
 * registered engine's class name against "plasma" / "ocean"
 * / "crystal" / "electric" / "halo". None of the 39 registered
 * engines are actually named that way (PulseEngine,
 * ConsciousnessEngine, MemoryEngine, etc. all write into
 * shared GenesisState fields instead of exposing an id/weight
 * of their own) — so crystal, electric, halo and plasma
 * permanently decayed to 0 a few frames after mount, and only
 * "ocean" (from OceanEngine) ever lit up, at a flat constant
 * value. The Crystal/Electric/Halo shells were wired into the
 * renderer but functionally invisible.
 *
 * Every one of those 39 engines DOES feed a rich shared
 * GenesisState (energy, awareness, consciousness, intelligence,
 * learning, memory, evolutionSystem, ocean, pulse, ...). That
 * state is the real "living" signal. So each shell channel is
 * now derived directly from the relevant slice of that state,
 * with an explicit engine-level override still honored for any
 * future engine that sets its own id + weight/getWeight — so
 * nothing here needs to change again if that pattern is used
 * later.
 * ==========================================================
 */

import type EngineRegistry from "./EngineRegistry";
import type { GenesisState } from "../state/GenesisState";
import type { GenesisSignals } from "./GenesisSignals";

export interface EngineWeights {

  plasma: number;

  ocean: number;

  crystal: number;

  electric: number;

  halo: number;

}

function clamp01(value: number): number {

  return Math.min(1, Math.max(0, value));

}

export default class EngineBus {

  private readonly registry: EngineRegistry;

  private readonly weights: EngineWeights = {

    plasma: 0.2,

    ocean: 0.3,

    crystal: 0.15,

    electric: 0.15,

    halo: 0.35,

  };

  constructor(

    registry: EngineRegistry,

  ) {

    this.registry = registry;

  }

  /**
   * Any engine that explicitly opts in with a matching id and
   * a weight / getWeight() still wins — this keeps the door
   * open for a future dedicated CrystalEngine, ElectricEngine,
   * HaloEngine, or PlasmaEngine without another rewrite here.
   */
  private readEngineOverrides(
    state: GenesisState,
  ): Partial<EngineWeights> {

    const overrides: Partial<EngineWeights> = {};

    for (const engine of this.registry.getAll()) {

      if (engine.enabled === false) {
        continue;
      }

      const id =
        (engine.id ?? engine.constructor.name).toLowerCase();

      const explicit =
        engine.getWeight?.(state) ?? engine.weight;

      if (explicit === undefined) {
        continue;
      }

      if (id.includes("plasma")) {
        overrides.plasma = explicit;
      }
      else if (id.includes("crystal")) {
        overrides.crystal = explicit;
      }
      else if (id.includes("electric")) {
        overrides.electric = explicit;
      }
      else if (id.includes("halo")) {
        overrides.halo = explicit;
      }
      else if (id.includes("ocean")) {
        overrides.ocean = explicit;
      }

    }

    return overrides;

  }

  update(

    state: GenesisState,

    delta: number,

    signals?: GenesisSignals,

  ): void {

    const overrides = this.readEngineOverrides(state);

    const engaged =
      Boolean(signals?.thinking) ||
      Boolean(signals?.reasoningActive) ||
      Boolean(signals?.planningActive) ||
      Boolean(signals?.speaking);

    /*
     * PLASMA — raw formative energy.
     * Dedicated evolutionSystem.plasma field, lifted by
     * overall energy and active mutation.
     */
    const plasma =
      overrides.plasma ??
      clamp01(
        state.evolutionSystem.plasma * 0.6 +
        state.energy * 0.25 +
        state.evolutionSystem.mutation * 0.15,
      );

    /*
     * OCEAN — fluid ambient body beneath the core.
     * Driven by the ocean sub-state itself; storms/tsunamis
     * push it up, stability settles it back down.
     */
    const oceanState = state.ocean;
    const ocean =
      overrides.ocean ??
      clamp01(
        oceanState.tide * 0.25 +
        oceanState.current * 0.2 +
        oceanState.wave * 0.25 +
        oceanState.stormSurge * 0.2 +
        oceanState.tsunami * 0.3 -
        (1 - oceanState.stability) * 0.1,
      );

    /*
     * CRYSTAL — structured cognition: intelligence, learning,
     * knowledge accumulating into memory.
     */
    const crystal =
      overrides.crystal ??
      clamp01(
        state.intelligence * 0.35 +
        state.learning * 0.25 +
        state.memory.longTerm * 0.2 +
        state.memory.importance * 0.2,
      );

    /*
     * ELECTRIC — moment-to-moment activity: raw energy, the
     * heartbeat's intensity, and instability arcing across the
     * shell. Also gets an instant lift while LÉLU is actively
     * engaged (thinking / reasoning / planning / speaking)
     * rather than waiting for state to catch up next tick.
     */
    const electric =
      overrides.electric ??
      clamp01(
        state.energy * 0.35 +
        state.pulse.intensity * 0.3 +
        state.evolutionSystem.instability * 0.2 +
        (engaged ? 0.25 : 0),
      );

    /*
     * HALO — the ambient aura of awareness / consciousness /
     * a settled sense of existence around the core.
     */
    const halo =
      overrides.halo ??
      clamp01(
        state.awareness * 0.3 +
        state.consciousness * 0.3 +
        state.existence * 0.2 +
        state.reality * 0.2,
      );

    const target: EngineWeights = {
      plasma,
      ocean,
      crystal,
      electric,
      halo,
    };

    const speed =

      Math.min(

        delta * 4,

        1,

      );

    this.weights.plasma +=

      (target.plasma - this.weights.plasma) *

      speed;

    this.weights.ocean +=

      (target.ocean - this.weights.ocean) *

      speed;

    this.weights.crystal +=

      (target.crystal - this.weights.crystal) *

      speed;

    this.weights.electric +=

      (target.electric - this.weights.electric) *

      speed;

    this.weights.halo +=

      (target.halo - this.weights.halo) *

      speed;

  }

  getWeights(): EngineWeights {

    return {

      ...this.weights,

    };

  }

}
