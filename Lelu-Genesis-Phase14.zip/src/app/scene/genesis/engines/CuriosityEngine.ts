/**
 * ==========================================================
 * LÉLUVERSE
 * CURIOSITY ENGINE
 *
 * Exploration and discovery pressure.
 *
 * Consciousness creates curiosity.
 * Curiosity creates evolution.
 * ==========================================================
 */

import type {
  GenesisState,
} from "../state/GenesisState";


export default class CuriosityEngine {


  update(

    state: GenesisState,

    delta:number,

  ):void {


    if(state.paused)

      return;



    if(

      state.curiosity <= 0

    )

      return;



    /*
     * Curiosity drives exploration
     */

    const exploration =

      state.curiosity *

      state.learning;



    /*
     * Increase evolution adaptation
     */

    state.evolutionSystem.adaptation = Math.min(

      1,

      state.evolutionSystem.adaptation +

      exploration *

      delta *

      0.01,

    );



    /*
     * Curiosity improves learning efficiency
     */

    state.learning = Math.min(

      1,

      state.learning +

      state.curiosity *

      delta *

      0.004,

    );



    /*
     * Curiosity feeds simulation complexity
     */

    state.simulation +=

      state.curiosity *

      delta *

      0.05;


    /*
     * Curiosity is the one paired field in this codebase that
     * only ever climbed — every other rise/fall pair (awareness'
     * attending/idle split, pulse.intensity, chaos vs harmony)
     * relaxes back down. This restores that missing other half
     * with a small constant decay, so growth above still has to
     * outpace it rather than curiosity climbing forever.
     */
    state.curiosity = Math.max(

      0,

      state.curiosity -

      delta *

      0.002,

    );


  }


}