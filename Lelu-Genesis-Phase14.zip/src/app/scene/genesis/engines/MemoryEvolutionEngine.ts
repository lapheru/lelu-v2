/**
 * ==========================================================
 * LÉLUVERSE
 * MEMORY EVOLUTION ENGINE
 *
 * Unused memory fades. Reinforced memory holds.
 * ==========================================================
 *
 * `state.memory.importance` only ever rose before this engine
 * existed — several engines push it up, nothing pulled it down.
 * This mirrors the existing EntropyEngine vs HarmonyEngine
 * tug-of-war pattern on `state.chaos`: the "evolution" of memory
 * includes forgetting, not just accumulation.
 *
 * Deliberately does NOT touch `memory.longTerm` or
 * `memory.archived` — those read as "already consolidated /
 * preserved" elsewhere in this codebase, and decaying them would
 * contradict that framing. Only `importance` (which reads as
 * "currently mattering") gets a decay term.
 * ==========================================================
 */

import type {
  GenesisState,
} from "../state/GenesisState";

export default class MemoryEvolutionEngine {

  update(
    state: GenesisState,
    delta: number,
  ): void {

    if (state.paused) return;

    state.memory.importance = Math.max(
      0,
      state.memory.importance - delta * 0.0015,
    );

  }

}
