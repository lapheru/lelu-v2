/**
 * ==========================================================
 * LÉLUVERSE
 * TIMELINE ENGINE
 *
 * Chronicles era transitions as they happen.
 * ==========================================================
 *
 * `state.era` is computed every tick by EvolutionEngine, but
 * nothing recorded WHEN those transitions happened — the value
 * just got overwritten. This engine owns a parallel history of
 * the universe's own era progression, logged to
 * `state.eraTimeline`.
 *
 * Does NOT own `state.age` or `state.timeline` (the simulation
 * calendar) — those stay owned by GenesisSimulation. Writing
 * age here as well used to double-increment it every tick.
 * ==========================================================
 */

import type {
  GenesisState,
} from "../state/GenesisState";

export default class TimelineEngine {

  private lastEra: string | null = null;

  update(
    state: GenesisState,
    _delta: number,
  ): void {

    if (state.paused) return;

    if (this.lastEra === null) {
      this.lastEra = state.era ?? null;
      return;
    }

    if (state.era !== this.lastEra) {

      state.eraTimeline.push({
        era: state.era ?? "UNKNOWN",
        age: state.age,
      });

      this.lastEra = state.era ?? null;

    }

  }

}
