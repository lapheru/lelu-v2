/**
 * ==========================================================
 * LÉLUVERSE
 * WISDOM ENGINE
 *
 * Knowledge, tested by time, kept.
 * ==========================================================
 *
 * No existing field represented "wisdom" — the closest existing
 * concepts are `teaching` and `memory.archived`. This engine
 * treats wisdom as those two, sustained over time — knowledge
 * that has actually lasted, not just accumulated.
 * ==========================================================
 */

import type {
  GenesisState,
} from "../state/GenesisState";

export default class WisdomEngine {

  update(
    state: GenesisState,
    delta: number,
  ): void {

    if (state.paused) return;

    const seasoned =
      (state.teaching + state.memory.archived) / 2;

    state.wisdom = Math.min(
      1,
      state.wisdom +
      seasoned * delta * 0.001,
    );

  }

}
